# F# Quiz App with Timer & Leaderboard

Ez a kis F# + Fable + Elmish alapú webalkalmazás egy 3 szintes, 30 kérdéses kvízt valósít meg, időmérővel és „skip” gombbal, valamint név bekérése után toplista-(leaderboard) funkcióval.

---

## Követelmények

- [.NET 7 SDK](https://dotnet.microsoft.com/download/dotnet/7.0)  
- [Node.js (LTS)](https://nodejs.org/) és NPM  
- (opcionálisan) Globális Fable CLI:
  ```bash
  dotnet tool install --global fable
  ```

---

## Projekt struktúra

```
QuizApp/
├── public/
│   ├── index.html
│   └── style.css
├── src/
│   ├── QuizApp.fsproj
│   ├── Quiz.fs
│   ├── Model.fs
│   ├── Msg.fs
│   ├── Update.fs
│   ├── View.fs
│   └── Program.fs
├── package.json
└── webpack.config.js
```

---

## public/index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>F# Quiz App with Timer & Leaderboard</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <div id="root"></div>
    <script src="bundle.js"></script>
</body>
</html>
```

## public/style.css
```css
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f4f4f4;
}
#root {
    max-width: 600px;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
button {
    margin-top: 10px;
}
.skip-button {
    background-color: #f39c12;
    color: white;
    border: none;
    padding: 8px;
    cursor: pointer;
    margin-left: 10px;
}
.skip-button:disabled {
    background-color: #ccc;
    cursor: default;
}
.timer {
    font-weight: bold;
    margin-bottom: 10px;
}
.leaderboard {
    margin-top: 20px;
    border-top: 1px solid #ddd;
    padding-top: 10px;
}
.leaderboard ul { list-style: none; padding: 0; }
.leaderboard li { margin-bottom: 4px; }
```

## forráskód mód

A `package.json`-ban a `start` script állítsa be:
```json
"start": "dotnet tool run fable watch src/QuizApp.fsproj --outDir public --outFile public/Program.js --run "webpack serve --mode development""
```
és a `webpack.config.js`:
```js
devServer: { static: './public', port: 8080 },
```

---

### Indítás
```bash
cd "C:\Projektek\projekt\QuizApp"
dotnet tool restore
dotnet restore src/QuizApp.fsproj
npm install
npm start
```
Nyisd meg: http://localhost:8080
