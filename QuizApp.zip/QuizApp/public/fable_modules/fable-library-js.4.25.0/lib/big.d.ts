/**
 * @type object
 */
export const Big: object;
export default Big;
