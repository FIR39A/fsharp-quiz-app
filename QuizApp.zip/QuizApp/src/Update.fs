module Update

open Quiz
open Model
open Msg

let leaderboard = ref []

let questionsForLevel level =
    match level with 1 -> Easy | 2 -> Medium | _ -> Hard
    |> pickQuestions 10

let initState lvl = {
    Level = lvl
    Questions = questionsForLevel lvl
    CurrentIndex = 0
    Score = 0
    Finished = false
    SkipUsed = false
    TimeLeft = questionTime
    PlayerName = ""
}

let update msg model =
    match model, msg with
    | NotStarted, StartQuiz -> InProgress (initState 1)
    | InProgress st, EnterName name -> InProgress { st with PlayerName = name }
    | InProgress st, Tick when not st.Finished ->
        let tl = st.TimeLeft - 1
        if tl <= 0 then
            let idx = st.CurrentIndex + 1
            let fin = idx >= List.length st.Questions
            InProgress { st with CurrentIndex = idx; Finished = fin; TimeLeft = questionTime }
        else InProgress { st with TimeLeft = tl }
    | InProgress st, Skip when not st.Finished && not st.SkipUsed ->
        let idx = st.CurrentIndex + 1
        let fin = idx >= List.length st.Questions
        InProgress { st with CurrentIndex = idx; Finished = fin; SkipUsed = true; TimeLeft = questionTime }
    | InProgress st, Answer i when not st.Finished ->
        let q = st.Questions.[st.CurrentIndex]
        let sc = if i = q.AnswerIndex then st.Score + 1 else st.Score
        let idx = st.CurrentIndex + 1
        let fin = idx >= List.length st.Questions
        InProgress { st with CurrentIndex = idx; Score = sc; Finished = fin; TimeLeft = questionTime }
    | InProgress st, NextStep when st.Finished && st.Level < 3 -> InProgress (initState (st.Level + 1))
    | InProgress st, NextStep when st.Finished -> Completed st.Score
    | Completed score, SubmitScore ->
        leaderboard := (!leaderboard) @ [ (match model with InProgress st -> st.PlayerName | _ -> ""), score ]
        ShowLeaderboard !leaderboard
    | ShowLeaderboard _, ViewLeaderboard -> NotStarted
    | Completed _, Restart
    | ShowLeaderboard _, Restart -> NotStarted
    | _ -> model