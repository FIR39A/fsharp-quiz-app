module Model

open Quiz

let questionTime = 15

type State = {
    Level: int
    Questions: Question list
    CurrentIndex: int
    Score: int
    Finished: bool
    SkipUsed: bool
    TimeLeft: int
    PlayerName: string
}

type Model =
    | NotStarted
    | InProgress of State
    | Completed of int
    | ShowLeaderboard of (string * int) list

let initModel = NotStarted