module Msg

type Msg =
    | StartQuiz
    | Answer of int
    | NextStep
    | Restart
    | Skip
    | Tick
    | EnterName of string
    | SubmitScore
    | ViewLeaderboard