module View

open Fable.React
open Fable.React.Props
open Model
open Msg

let questionView q dispatch =
    div [] [
        h3 [] [ str q.Text ]
        ul [] (q.Options |> List.mapi (fun i o -> li [] [ button [ OnClick(fun _ -> dispatch (Answer i)) ] [ str o ] ]))
    ]

let view model dispatch =
    match model with
    | NotStarted ->
        div [] [
            h2 [] [ str "Enter your name:" ]
            input [ Type "text"; Placeholder "Name"; OnChange(fun ev -> dispatch (EnterName ev.Value)) ] []
            button [ OnClick(fun _ -> dispatch StartQuiz) ] [ str "Start Quiz" ]
        ]
    | InProgress st when not st.Finished ->
        div [] [
            div [ ClassName "timer" ] [ str (sprintf "Time left: %d" st.TimeLeft) ]
            h2 [] [ str (sprintf "Level %d - Q %d/%d" st.Level (st.CurrentIndex + 1) (List.length st.Questions)) ]
            questionView st.Questions.[st.CurrentIndex] dispatch
            p [] [ str (sprintf "Score: %d" st.Score) ]
            button [ ClassName "skip-button"; OnClick(fun _ -> dispatch Skip); Disabled st.SkipUsed ] [ str (if st.SkipUsed then "Skip used" else "Skip Question") ]
        ]
    | Completed score ->
        div [] [
            h2 [] [ str (sprintf "%s, you scored %d!" (match model with InProgress st -> st.PlayerName | _ -> "Player") score) ]
            button [ OnClick(fun _ -> dispatch SubmitScore) ] [ str "Submit Score" ]
        ]
    | ShowLeaderboard entries ->
        div [] [
            h2 [] [ str "Leaderboard" ]
            div [ ClassName "leaderboard" ] [
                ul [] (entries |> List.map (fun (n,s) -> li [] [ str (sprintf "%s: %d" n s) ]))
            ]
            button [ OnClick(fun _ -> dispatch Restart) ] [ str "Play Again" ]
        ]