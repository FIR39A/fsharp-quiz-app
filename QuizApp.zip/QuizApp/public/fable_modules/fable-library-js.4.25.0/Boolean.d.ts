import { FSharpRef } from "./Types.js";
export declare function tryParse(str: string, defValue: FSharpRef<boolean>): boolean;
export declare function parse(str: string): boolean;
