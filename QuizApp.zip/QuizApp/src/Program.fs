module Program

open Elmish
open Elmish.React
open Fable.Core.JsInterop
open Browser.Dom
open Model
open Update
open View

let timerSub dispatch =
    let id = window.setInterval((fun _ -> dispatch Tick), 1000.0)
    { new System.IDisposable with member _.Dispose() = window.clearInterval(id) }

Program.mkProgram (fun () -> initModel, Cmd.none) update view
|> Program.withReact "root"
|> Program.withSubscription (fun model -> if matches<|> model<|> InProgress then Cmd.ofSub timerSub else Cmd.none)
|> Program.run