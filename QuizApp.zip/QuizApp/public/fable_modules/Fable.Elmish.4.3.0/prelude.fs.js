import { some } from "../fable-library-js.4.25.0/Option.js";
import Timer from "../fable-library-js.4.25.0/Timer.js";
import { add } from "../fable-library-js.4.25.0/Observable.js";
import { startImmediate } from "../fable-library-js.4.25.0/Async.js";

export function Log_onError(text, ex) {
    console.error(some(text), ex);
}

export function Log_toConsole(text, o) {
    console.log(some(text), o);
}

export function Timer_delay(interval, callback) {
    let t;
    let returnVal = new Timer(interval);
    returnVal.AutoReset = false;
    t = returnVal;
    add(callback, t.Elapsed());
    t.Enabled = true;
    t.Start();
}

export function AsyncHelpers_start(x) {
    Timer_delay(1, (_arg) => {
        startImmediate(x);
    });
}

