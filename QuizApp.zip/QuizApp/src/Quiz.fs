module Quiz

open System

type Question = {
    Text: string
    Options: string list
    AnswerIndex: int
}

type Difficulty =
    | Easy
    | Medium
    | Hard

let questionBank: (Difficulty * Question) list = [
    // Easy questions (10)
    Easy, { Text = "2 + 2 = ?"; Options = ["3"; "4"; "5"]; AnswerIndex = 1 }
    Easy, { Text = "Capital of France?"; Options = ["Paris"; "Rome"; "Berlin"]; AnswerIndex = 0 }
    Easy, { Text = "5 - 3 = ?"; Options = ["1"; "2"; "3"]; AnswerIndex = 1 }
    Easy, { Text = "Color of the sky?"; Options = ["Blue"; "Green"; "Red"]; AnswerIndex = 0 }
    Easy, { Text = "1 + 1 = ?"; Options = ["2"; "3"; "4"]; AnswerIndex = 0 }
    Easy, { Text = "Square of 2?"; Options = ["2"; "4"; "6"]; AnswerIndex = 1 }
    Easy, { Text = "3 - 2 = ?"; Options = ["1"; "2"; "0"]; AnswerIndex = 0 }
    Easy, { Text = "Sun rises in the?"; Options = ["East"; "West"; "North"]; AnswerIndex = 0 }
    Easy, { Text = "10 / 2 = ?"; Options = ["4"; "5"; "6"]; AnswerIndex = 1 }
    Easy, { Text = "6 + 3 = ?"; Options = ["8"; "9"; "10"]; AnswerIndex = 1 }

    // Medium questions (10)
    Medium, { Text = "3 * 7 = ?"; Options = ["21"; "24"; "18"]; AnswerIndex = 0 }
    Medium, { Text = "Square root of 49?"; Options = ["6"; "7"; "8"]; AnswerIndex = 1 }
    Medium, { Text = "12 / 3 = ?"; Options = ["4"; "3"; "5"]; AnswerIndex = 0 }
    Medium, { Text = "5^2 = ?"; Options = ["10"; "25"; "20"]; AnswerIndex = 1 }
    Medium, { Text = "9 * 2 = ?"; Options = ["18"; "16"; "20"]; AnswerIndex = 0 }
    Medium, { Text = "7 + 8 = ?"; Options = ["14"; "15"; "16"]; AnswerIndex = 1 }
    Medium, { Text = "8 - 3 = ?"; Options = ["4"; "5"; "6"]; AnswerIndex = 1 }
    Medium, { Text = "11 / 11 = ?"; Options = ["0"; "1"; "11"]; AnswerIndex = 1 }
    Medium, { Text = "4^2 = ?"; Options = ["8"; "12"; "16"]; AnswerIndex = 2 }
    Medium, { Text = "6 * 6 = ?"; Options = ["36"; "30"; "42"]; AnswerIndex = 0 }

    // Hard questions (10)
    Hard, { Text = "12! / (10! * 2!) = ?"; Options = ["66"; "72"; "56"]; AnswerIndex = 0 }
    Hard, { Text = "Integral of x dx = ?"; Options = ["x"; "x^2/2 + C"; "ln x"]; AnswerIndex = 1 }
    Hard, { Text = "Derivative of x^2 = ?"; Options = ["2x"; "x"; "x^2"]; AnswerIndex = 0 }
    Hard, { Text = "Limit of (1+1/n)^n as n→∞?"; Options = ["e"; "1"; "2"]; AnswerIndex = 0 }
    Hard, { Text = "cos(0) = ?"; Options = ["0"; "1"; "-1"]; AnswerIndex = 1 }
    Hard, { Text = "log10(100) = ?"; Options = ["1"; "2"; "3"]; AnswerIndex = 1 }
    Hard, { Text = "5! = ?"; Options = ["120"; "24"; "60"]; AnswerIndex = 0 }
    Hard, { Text = "√(16) = ?"; Options = ["2"; "4"; "8"]; AnswerIndex = 1 }
    Hard, { Text = "30/5 = ?"; Options = ["5"; "6"; "8"]; AnswerIndex = 1 }
    Hard, { Text = "2^5 = ?"; Options = ["32"; "16"; "64"]; AnswerIndex = 0 }
]

let shuffle rnd xs = xs |> List.map (fun x -> rnd.Next(), x) |> List.sortBy fst |> List.map snd
let pickQuestions difficulty count = let rnd = Random() in questionBank |> List.filter (fst >> ((=) difficulty)) |> List.map snd |> shuffle rnd |> List.take count