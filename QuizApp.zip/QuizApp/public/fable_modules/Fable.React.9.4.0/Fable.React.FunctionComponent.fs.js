import { class_type } from "../fable-library-js.4.25.0/Reflection.js";
import { ReactElementTypeModule_memoWith } from "./Fable.React.Helpers.fs.js";
import * as react from "react";

export class FunctionComponentPreparedRenderFunctionCache {
    constructor() {
    }
}

export function FunctionComponentPreparedRenderFunctionCache_$reflection() {
    return class_type("Fable.React.FunctionComponentPreparedRenderFunctionCache", undefined, FunctionComponentPreparedRenderFunctionCache);
}

export function FunctionComponentPreparedRenderFunctionCache_$ctor() {
    return new FunctionComponentPreparedRenderFunctionCache();
}

(() => {
    let cache;
    FunctionComponentPreparedRenderFunctionCache.cache = ((cache = (new Map()), (typeof module === 'object'
&& typeof module.hot === 'object'
&& typeof module.hot.addStatusHandler === 'function'
? module.hot.addStatusHandler(status => { if (status === 'apply') (() => {
        cache.clear();
    })(); })
: void 0, cache)));
})();

export function FunctionComponentPreparedRenderFunctionCache_GetOrAdd_3560CE5E(cacheKey, displayName, render, memoizeWith, withKey, __callingMemberName) {
    const prepareRenderFunction = () => {
        render.displayName = displayName;
        let elemType;
        if (memoizeWith == null) {
            elemType = render;
        }
        else {
            const areEqual = memoizeWith;
            const areEqual_1 = (x, y) => {
                if (!(typeof module === 'object'
&& typeof module.hot === 'object'
&& typeof module.hot.status === 'function'
&& module.hot.status() === 'apply')) {
                    return areEqual(x, y);
                }
                else {
                    return false;
                }
            };
            const memoElement = ReactElementTypeModule_memoWith(areEqual_1, render);
            memoElement.displayName = (("Memo(" + displayName) + ")");
            elemType = memoElement;
        }
        return (props) => {
            let props_1;
            if (withKey == null) {
                props_1 = props;
            }
            else {
                const f_1 = withKey;
                props.key = f_1(props);
                props_1 = props;
            }
            return react.createElement(elemType, props_1);
        };
    };
    if (FunctionComponentPreparedRenderFunctionCache.cache.has(cacheKey)) {
        return FunctionComponentPreparedRenderFunctionCache.cache.get(cacheKey);
    }
    else {
        const v = prepareRenderFunction();
        FunctionComponentPreparedRenderFunctionCache.cache.set(cacheKey, v);
        return v;
    }
}

export class FunctionComponent {
    constructor() {
    }
}

export function FunctionComponent_$reflection() {
    return class_type("Fable.React.FunctionComponent", undefined, FunctionComponent);
}

